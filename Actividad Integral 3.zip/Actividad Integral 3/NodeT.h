#include "Bitacora.h"

class NodeT{
    public:
        NodeT(Bitacora data);
        NodeT* getLeft();
        NodeT* getRight();
        void setLeft(NodeT *left);
        void setRight(NodeT *right);
        long long getIp();
        Bitacora getData();
        int getKey();
    private:
        Bitacora data;
        long long ip;
        int key;
        NodeT *left;
        NodeT *right;
        string ips;
};

NodeT::NodeT(Bitacora data){
    this->data = data;
    ips = data.getIps();
    ip = data.getIp();
    key = data.getKey();
    left = nullptr;
    right = nullptr;
}

Bitacora NodeT::getData(){
    return data;
}

NodeT* NodeT::getLeft(){
    return left;
}

NodeT* NodeT::getRight(){
    return right;
}

void NodeT::setLeft(NodeT *left){
    this->left = left;
}

void NodeT::setRight(NodeT *right){
    this->right = right;
}

long long NodeT::getIp(){
    return ip;
}

int NodeT::getKey(){
    return key;
}