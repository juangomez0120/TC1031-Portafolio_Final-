#ifndef Bitacora_h
#define Bitacora_h
#include <string>
using namespace std;

class Bitacora
{
private:
    string mes;
    string dia;
    string hora;
    string ip;
    string log;
    int comparador;
public:
    Bitacora(string mes, int dia, string hora, string ip, string log);
    Bitacora();
    string mesToNum(string mes);
    int concat(string s1, string s2);
    void print();
    int getComparador();
    string getMes();
    string getDia();
    string getHora();
    string getIp();
    string getLog();
};

Bitacora::Bitacora(string mes, int dia, string hora, string ip, string log)
{
    this->mes = mes;
    if(dia < 10){
        this->dia = "0" + to_string(dia);
    } else {this->dia = to_string(dia);}
    this->hora = hora;
    this->ip = ip;
    this->log = log;
    comparador = stoi(mesToNum(this->mes)+this->dia);
}

Bitacora::Bitacora(){
    mes = "0";
    dia = "0";
    hora = "0";
    ip = "0";
    log = "0";
    comparador = 0;
}

void Bitacora::print(){
    cout << mes << " " << dia << " " << hora << " " << ip << " " << log << endl;
}

string Bitacora::mesToNum(string mes){
    if(mes == "Ene"){
        return "1";
    }
    if(mes == "Feb"){
        return "2";
    }
    if(mes == "Mar"){
        return "3";
    }
    if(mes == "Apr"){
        return "4";
    }
    if(mes == "May"){
        return "5";
    }
    if(mes == "Jun"){
        return "6";
    }
    if(mes == "Jul"){
        return "7";
    }
    if(mes == "Aug"){
        return "8";
    }
    if(mes == "Sep"){
        return "9";
    }
    if(mes == "Oct"){
        return "10";
    }
    if(mes == "Nov"){
        return "11";
    }
    if(mes == "Dic"){
        return "12";
    }
    else{
        return 0;
    }
}

int Bitacora::getComparador(){
    return comparador;
}

string Bitacora::getMes(){
    return mes;
}

string Bitacora::getDia(){
    return dia;
}

string Bitacora::getHora(){
    return hora;
}

string Bitacora::getIp(){
    return ip;
}

string Bitacora::getLog(){
    return log;
}



#endif