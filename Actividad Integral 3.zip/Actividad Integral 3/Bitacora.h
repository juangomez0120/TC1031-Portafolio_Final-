#include <string>
#include <sstream>
#include <algorithm>
using namespace std;
class Bitacora{
    private:
        long long ip;
        int key;
        string ips;
    public:
        Bitacora(string ip, int key);
        Bitacora();
        long long convIp(string ip);
        int getKey();
        string getIps();
        long long getIp();
};

// Constructor
// Complejidad: O(1)
Bitacora::Bitacora(string ip, int key){
    ips = ip;
    this->ip = convIp(ip);
    this->key = key;
}
// Getter
// Complejidad: O(1)
string Bitacora::getIps(){
    return ips;
}

// Constructor def
// Complejidad: O(1)
Bitacora::Bitacora(){
    ip = 0;
    key = 0;
    ips = "0";
}

//Convertor de string a long long
// Complejidad: O(n)
// Entrada: Ip en string
// Salida: Ip en long long
long long Bitacora::convIp(string ip){
    ip.erase(remove(ip.begin(), ip.end(), '.'), ip.end());
    stringstream geek(ip);
    long long x = 0;
    geek >> x;
    return x;
}

// Getters
// Complejidad: O(1)
int Bitacora::getKey(){
    return key;
}

long long Bitacora::getIp(){
    return ip;
}