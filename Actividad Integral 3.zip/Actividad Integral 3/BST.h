#include "NodeT.h"
#include <algorithm>
#include <string>
#include <queue>
#include <iostream>
using namespace std;
class BST{
    public:
        BST();
        ~BST();
        void add(Bitacora data);
        void inOrden(NodeT *r, queue<Bitacora> &data);
        NodeT* getRoot();
        void print();
    private:
        NodeT *root;
        void destruye(NodeT *r);
};

// Constructor
// Entrada: NA
// Salida: NA
// Complejidad: O(1)
BST::BST(){
    root = nullptr;
}

// Destructor
// Llama a la funcion destruye
// Entrada: NA
// Salida: NA
BST::~BST(){
    destruye(root);
}

// Getter
// Complejidad: O(1)
// Entrada: NA
// Salida: Raiz del arbol
NodeT* BST::getRoot(){
    return root;
}

// Destructor
// Complejidad: O(logn)
// Entrada: Raiz del arbol
// Salida: NA
void BST::destruye(NodeT *r){
    if(r!=nullptr){
        destruye(r->getLeft());
        destruye(r->getRight());
        delete r;
    }
}

// Agrega datos al BST
// Complejidad: O(logn)
// Entrada: Dato a ingresar
// Salida: NA
void BST::add(Bitacora data){
    NodeT *curr = root;
    NodeT *father = nullptr;
    while(curr!=nullptr){
        father = curr;
        if (curr->getKey() > data.getKey()){
            curr = curr->getLeft();
        }
        else if (curr->getKey() < data.getKey()){
            curr = curr->getRight();
        }
        else {
            if (curr->getIp() > data.getIp()){
                curr = curr->getLeft();
            } else {
                curr = curr->getRight();
            }
        }
    }
    if (father == nullptr){
        root = new NodeT(data);
    } else {
        if (father->getKey() > data.getKey()){
            father->setLeft(new NodeT(data));
        }
        else if (father->getKey() < data.getKey()){
            father->setRight(new NodeT(data));
        }
        else {
            if (father->getIp() > data.getIp()){
                father->setLeft(new NodeT(data));
            } else {
                father->setRight(new NodeT(data));
            }
        }
    }
}

// Lectura de datos en inOrden reverso
// Se agregan datos a un queue para su impresion mas adelante
// Complejidad del inOrden: O(logn)
// Complejidad de agregar datos al queue: O(1)
// Entrada: Raiz del arbol y queue para agregar datos
// Salida: NA
void BST::inOrden(NodeT *r, queue<Bitacora> &data){
    if(r!=nullptr){
        inOrden(r->getRight(), data);
        data.push(r->getData());
        inOrden(r->getLeft(), data);
    }
}

// Impresion de las ips
// Complejidad: O(n)
// Entrada: NA
// Salida: NA
void BST::print(){
    queue<Bitacora> datos;
    inOrden(root, datos);
    for (int i = 0; i<5; i++){
        cout << "IP: " << datos.front().getIps() << " tiene " << datos.front().getKey() << " accesos." << endl;
        datos.pop();
    }
}







