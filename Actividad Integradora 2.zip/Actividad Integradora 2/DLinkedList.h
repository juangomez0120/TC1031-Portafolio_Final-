#include "Node.h"
#include "Bitacora.h"
#include <iostream>
using namespace std;

template <class T>
class DLinkedList{
    public:
        DLinkedList();
        ~DLinkedList();
        void addFirst(T data);
        void addLast(T data);
        T getData(int pos);
        void setData(int pos, T data);
        int getSize();
        int read(T data);
        void replace(int pos1, int pos2);
        bool del(T data);
        void print();
        void printr();
    private:
        Node<T> *head;
        Node<T> *tail;
        int size;
};

// Constructor
// Complejidad: O(1)
template <class T>
DLinkedList<T>::DLinkedList(){
    head = nullptr;
    size = 0;
}

// Getter del size
// Complejidad: O(1)
template <class T>
int DLinkedList<T>::getSize(){
    return size;
}

// Getter de los datos
// Complejidad O(n)
template <class T>
T DLinkedList<T>::getData(int pos){
    Node<T> *curr = head;
    for(int i=0; i<pos; i++){
        curr = curr->getNext();
    }
    return curr->getData();
}

// Setter de los datos
// Complejidad O(n)
template <class T>
void DLinkedList<T>::setData(int pos, T data){
    Node<T> *curr = head;
    for(int i=0; i<pos; i++){
        curr = curr->getNext();
    }
    curr->setData(data);
}

// Replace, reemplaza adentro de la lista
// Complejidad O(n)
template <class T>
void DLinkedList<T>::replace(int pos1, int pos2){
    Node<T> *curr = head;
    int cont = 0;
    for (int i = 0; i<pos1; i++){
        curr = curr->getNext();
    }
    curr->setData(getData(pos2));
}

// AddFirst, agrega un valor al comienzo de la lista
// Complejidad, O(n)
template <class T>
void DLinkedList<T>::addFirst(T data){
    if (head == nullptr){
        head = new Node<T>(data);
        tail = head;
        size++;
    } else {
        head = new Node<T>(data, head, nullptr);
        head->getNext()->setPrev(head);
        size++;
    }
}

// AddLast, agrega un valor al final de la lista
// Complejidad O(n)
template <class T>
void DLinkedList<T>::addLast(T data){
    if (size == 0){
        addFirst(data);
    } else {
        tail = new Node<T>(data, nullptr, tail);
        tail->getPrev()->setNext(tail);
        size++;
    }
}

//Print
// Complejidad O(n)
template <class T>
void DLinkedList<T>::print(){
    cout << "La LL contiene: " << endl;
    Node<T> *curr = head;
    while (curr!=nullptr){
        //cout << curr->getData() << endl;
        curr->getData().print();
        curr = curr->getNext();
    }
}

// Destructor
// Complejidad O(n)
template <class T>
DLinkedList<T>::~DLinkedList(){
    Node<T> *curr = head;
    while (head != nullptr){
        head = head->getNext();
        delete curr;
        curr = head;
    }
    int sizeAux = size;
    size = 0;
}

// Print reverso
// Complejidad O(n)
template <class T>
void DLinkedList<T>::printr(){
    cout << "La LL contiene: " << endl;
    Node<T> *curr = tail;
    while (curr!=nullptr){
        cout << curr->getData() << endl;
        curr = curr->getPrev();
    }
}