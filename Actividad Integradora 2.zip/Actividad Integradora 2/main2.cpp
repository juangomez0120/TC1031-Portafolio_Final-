// Oscar Bastidas A01741481
//Juan Manuel Gomez A00828010
#include "DLinkedList.h"
#include "Bitacora.h"
#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;


int particion (DLinkedList<Bitacora> &list, int ini, int fin, int &pivote){
	long long elempivote = list.getData(ini).getIntIp(), j = ini, cant = 0;
    Bitacora temp;
	for (int i=ini+1; i<=fin; i++) {
		cant++;
      	if (list.getData(i).getIntIp() < elempivote) {
            j = j+1;
            temp = list.getData(i);
            list.replace(i, j);
            list.setData(j, temp);
		}
	}
	pivote = j;
    temp = list.getData(ini);
    list.replace(ini, pivote);
    list.setData(pivote, temp);
	return cant;
}
//Complejidad: n log(n), pero tambien hay que tener en cuenta la complejidad del recorrido de datos en la lista, que es O(n)
// Esta funcion hace el sort
int quick(DLinkedList<Bitacora> &v, int ini, int fin){
	int cant = 0, pivote;
	if (ini < fin) {
   		cant += particion(v, ini, fin, pivote);
   		cant += quick(v, ini, pivote-1);
   		cant += quick(v, pivote+1, fin);
	}
	return cant;
}

//Complejidad: Lineal, la funcion string.erase tiene complejidad lineal
// Esta funcion convierte a las IPs en long long para que sea posible realizar la busqueda y el ordenamiento
long long convIp(string ip){
    ip.erase(remove(ip.begin(), ip.end(), '.'), ip.end());
    ip.erase(remove(ip.begin(), ip.end(), ':'), ip.end());
    stringstream geek(ip);
    long long x = 0;
    geek >> x;
    return x;
}

// Complejidad log(n)
// Busqueda binaria
int busqBinariaMin(DLinkedList<Bitacora> &list, long long dato, int &cantBB){
	int ini = 0, fin = list.getSize()-1, mit;
	cantBB = 0;
	while (ini <= fin){
		mit = (ini+fin)/2;
		cantBB++;
		if (list.getData(mit).getIntIp() == dato){
			return mit;
		}
		if (list.getData(mit).getIntIp() > dato){
			fin = mit-1;
		}
		else{
			ini = mit +1;
		}
	}
	return -1;
}


int main(){ 
    DLinkedList<Bitacora> lista;
    ifstream bitacora_txt("bitacora.txt");
    stringstream ss;
    string linea, mes, hora, ip, log, valor, log_temp;
    int dia;
    char delim = ' ';
    int nd;
    // Lectura del archivo, complejidad O(n)
    while(getline(bitacora_txt, linea)){
        stringstream ss(linea);
        nd = 0;
        log = "";
        while(getline(ss, valor, delim)){
            if(nd == 0){
                mes = valor;
            }
            if(nd == 1){
                dia = stoi(valor);
            }
            if(nd == 2){
                hora = valor;
            }
            if(nd == 3){
                ip = valor;
            }
            if(nd >= 4){
                log += (valor + " ");
            }
            nd++;
        }
        Bitacora bitacora(mes, dia, hora, ip, log);
        lista.addLast(bitacora);
    }

    int ini = 0, fin = lista.getSize()-1;
    int cantBB = 0;
    

    quick(lista, 0, lista.getSize()-1); //Sort

    ofstream archivo2;
   archivo2.open("bitacora_ordenada.txt",ios::out); //Se crea el archivo. Si ya existe, lo reemplaza

   if (archivo2.fail()){ //En caso de error al crear el archivo
       cout << "No se pudo abrir el archivo" << endl;
       archivo2.close();
   }
   else{
       for(int i=0; i< lista.getSize(); i++){ //Escribe en el archivo en el mismo formato que la bitacora original, complejidad O(n)
           archivo2 << lista.getData(i).getMes() << " "; 
           archivo2 << lista.getData(i).getDia() << " "; 
           archivo2 << lista.getData(i).getHora() << " ";
           archivo2 << lista.getData(i).getIp() << " ";
           archivo2 << lista.getData(i).getLog() <<endl;
       }
       archivo2.close();
   }


    //Busqueda y condicionales
    
    string ip_busqueda_min;
    cout << "Ingrese la ip minima para buscar: " << endl;
    cin >> ip_busqueda_min;
    int indice_menor = busqBinariaMin(lista, convIp(ip_busqueda_min), cantBB);

    string ip_busqueda_max;
    cout << "Ingrese la ip maxima para buscar: " << endl;
    cin >> ip_busqueda_max;
    int indice_mayor = busqBinariaMin(lista, convIp(ip_busqueda_max), cantBB);

    if(indice_menor < 0 || indice_mayor < 0){
        cout << "Alguno de los datos no existe" << endl;
    } else if (ip_busqueda_min > ip_busqueda_max){
        cout << "El valor minimo es mayor que el maximo" << endl;
    } else{
        for (int i=indice_menor; i<=indice_mayor; i++){
            lista.getData(i).print();
        }
    }
}