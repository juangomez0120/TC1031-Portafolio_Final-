#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include "Bitacora.h"
using namespace std;


int particion (vector<Bitacora> &vec, int ini, int fin, int &pivote){
	int elempivote = vec[ini].getComparador(), j = ini, cant = 0;
    Bitacora temp;
	for (int i=ini+1; i<=fin; i++) {
		cant++;
      	if (vec[i].getComparador() < elempivote) {
            j = j+1;
            temp = vec[i];
            vec[i] = vec[j];
            vec[j] = temp;
		}
	}
	pivote = j;
	temp = vec[ini];
	vec[ini] = vec[pivote];
	vec[pivote] = temp;
	return cant;
}


int quick(vector<Bitacora> &v, int ini, int fin){
	int cant = 0, pivote;
	if (ini < fin) {
   		cant += particion(v, ini, fin, pivote);
   		cant += quick(v, ini, pivote-1);
   		cant += quick(v, pivote+1, fin);
	}
	return cant;
}

void print(vector<Bitacora> &v){
    for (int i = 0; i<v.size(); i++){
        v[i].print();
    }
}

int main(){
    ifstream bitacora_txt("bitacora.txt");
    stringstream ss;
    string linea, mes, hora, ip, log, valor, log_temp;
    int dia;
    vector<Bitacora> vec;
    char delim = ' ';
    int nd;
    while(getline(bitacora_txt, linea)){
        stringstream ss(linea);
        nd = 0;
        log = "";
        while(getline(ss, valor, delim)){
            if(nd == 0){
                mes = valor;
            }
            if(nd == 1){
                dia = stoi(valor);
            }
            if(nd == 2){
                hora = valor;
            }
            if(nd == 3){
                ip = valor;
            }
            if(nd >= 4){
                log += (valor + " ");
            }
            nd++;
        }
        Bitacora bitacora(mes, dia, hora, ip, log);
        vec.push_back(bitacora);
    }

    int ini = 0, fin = vec.size()-1;
    quick(vec, ini, fin);
    print(vec);
    return 0;
}