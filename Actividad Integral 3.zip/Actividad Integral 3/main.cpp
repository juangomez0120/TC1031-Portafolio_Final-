// Juan Manuel Gomez A00828010

#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
using namespace std;

#include "BST.h"

int main(){
    BST arbol;
    ifstream bitacora_txt("bitacoraOrdenada.txt");
    stringstream ss;
    string valor, ip, linea, ip_temp = "000";
    char delim = ' ';
    int nd, key = 1;
    // Lectura de los datos
    // Complejidad O(n)
    while (getline(bitacora_txt, linea)){
        stringstream ss(linea);
        nd = 0;
        while (getline(ss, valor, delim)){
            if (nd == 3){
                ip = valor.substr(0, valor.find(":"));
            }
            nd++;
        }
        if (ip_temp == "000"){
            ip_temp = ip;
        }
        else if (ip == ip_temp){
            key++;
        } 
        else if (ip != ip_temp) {
            Bitacora bitacora(ip_temp, key);
            arbol.add(bitacora);
            key = 1;
        }
        ip_temp = ip;
    }
    Bitacora bitacora(ip, key);
    arbol.add(bitacora);
    queue<long long> datos;
    arbol.print();
}
