#ifndef Bitacora_h
#define Bitacora_h
#include <string>
#include <iostream>
#include <algorithm>
#include <sstream>
using namespace std;

class Bitacora
{
private:
    string mes;
    string dia;
    string hora;
    long long ip_int;
    string ip;
    string log;
    int comparador;
public:
    Bitacora(string mes, int dia, string hora, string ip, string log);
    Bitacora();
    string mesToNum(string mes);
    long long convIp(string ip);
    int concat(string s1, string s2);
    void print();
    int getComparador();
    string getMes();
    string getDia();
    string getHora();
    long long getIntIp();
    string getIp();
    string getLog();
    bool operator==(Bitacora bitac);
};
// Constructor
// Complejidad O(1)
Bitacora::Bitacora(string mes, int dia, string hora, string ip, string log)
{
    this->mes = mes;
    if(dia < 10){
        this->dia = "0" + to_string(dia);
    } else {this->dia = to_string(dia);}
    this->hora = hora;
    this->ip_int = convIp(ip);
    this->ip = ip;
    this->log = log;
    comparador = stoi(mesToNum(this->mes)+this->dia);
}

// Constructor
// Complejidad O(1)
Bitacora::Bitacora(){
    mes = "0";
    dia = "0";
    hora = "0";
    ip_int = 0;
    ip = "0";
    log = "0";
    comparador = 0;
}

// Operador ==
// Complejidad O(1)
bool Bitacora::operator==(Bitacora bitac){
    if (hora == bitac.getHora() && mes == bitac.getMes() && hora == bitac.getHora()){
        return true;
    } else{
        return false;
    }
}

// Getter de ip
// Complejidad O(1)
string Bitacora::getIp(){
    return ip;
}

// Convertor de string a long long para la ip
// Complejidad O(n), su complejidad es por el string.erase
long long Bitacora::convIp(string ip){
    ip.erase(remove(ip.begin(), ip.end(), '.'), ip.end());
    ip.erase(remove(ip.begin(), ip.end(), ':'), ip.end());
    stringstream geek(ip);
    long long x = 0;
    geek >> x;
    return x;
}

// Print
// COmplejidad O(1)
void Bitacora::print(){
    cout << mes << " " << dia << " " << hora << " " << ip << " " << log << endl;
}

// Convertor de mes a numero
// Complejidad O(1)
string Bitacora::mesToNum(string mes){
    if(mes == "Ene"){
        return "1";
    }
    if(mes == "Feb"){
        return "2";
    }
    if(mes == "Mar"){
        return "3";
    }
    if(mes == "Apr"){
        return "4";
    }
    if(mes == "May"){
        return "5";
    }
    if(mes == "Jun"){
        return "6";
    }
    if(mes == "Jul"){
        return "7";
    }
    if(mes == "Aug"){
        return "8";
    }
    if(mes == "Sep"){
        return "9";
    }
    if(mes == "Oct"){
        return "10";
    }
    if(mes == "Nov"){
        return "11";
    }
    if(mes == "Dic"){
        return "12";
    }
    else{
        return 0;
    }
}

// getter Comparador
// complejidad O(1) 
int Bitacora::getComparador(){
    return comparador;
}

//Todos estos son getters y sus complejidades son O(1)

string Bitacora::getMes(){
    return mes;
}

string Bitacora::getDia(){
    return dia;
}

string Bitacora::getHora(){
    return hora;
}

long long Bitacora::getIntIp(){
    return ip_int;
}

string Bitacora::getLog(){
    return log;
}



#endif